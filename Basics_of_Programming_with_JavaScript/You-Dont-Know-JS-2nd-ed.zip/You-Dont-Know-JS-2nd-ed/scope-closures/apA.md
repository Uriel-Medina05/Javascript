# You Don't Know JS Yet: Scope & Closures - 2nd Edition
# Appendix A: Exploring Further

| NOTE: |
| :--- |
| Work in progress |

// TODO
