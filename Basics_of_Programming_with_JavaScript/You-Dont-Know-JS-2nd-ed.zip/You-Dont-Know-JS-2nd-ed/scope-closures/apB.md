# You Don't Know JS Yet: Scope & Closures - 2nd Edition
# Appendix B: Practice

// TODO
