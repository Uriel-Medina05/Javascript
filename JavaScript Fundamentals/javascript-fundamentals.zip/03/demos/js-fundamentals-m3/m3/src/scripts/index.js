
for (let i=0; i<5; i++) { 
  if (i === 3) 
    continue;
  console.log(i);
}
