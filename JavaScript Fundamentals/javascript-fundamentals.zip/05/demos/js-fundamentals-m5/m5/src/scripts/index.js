
let trackCar = function(city='NY', carId) {
  console.log(`Tracking ${carId} in ${city}.`);
};

console.log( trackCar(123) ); 

console.log( trackCar(123, 'Chicago'));

