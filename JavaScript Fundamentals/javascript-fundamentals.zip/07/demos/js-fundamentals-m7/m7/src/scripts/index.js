
import { Car } from './models/car.js';

let car = new Car(123);
console.log( car.id );  
 
