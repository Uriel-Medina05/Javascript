
export class Car {
    constructor(id) {
        this.id = id;
    }
}