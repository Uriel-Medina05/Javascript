
let element = document.getElementById('first');

element.style.color = 'blue';

console.log(element);
