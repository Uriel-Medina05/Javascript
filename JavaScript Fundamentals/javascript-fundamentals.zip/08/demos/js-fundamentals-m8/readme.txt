
### JavaScript Fundamentals - Module 8 - Programming the BOM and DOM

This folder contains the dev environment set up in Module 1 of this course, along with the final script.js file created in the module.

Be sure to execute:

npm install

Which will set up your node_modules folder.

To run in dev mode, execute:

npm run dev