
console.log('Hello World!');
